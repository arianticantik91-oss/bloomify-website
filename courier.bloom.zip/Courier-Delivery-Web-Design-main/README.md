CourierX — Courier Delivery Website

One-line (SEO) tagline: Fast, reliable same-day courier delivery for businesses and individuals — track shipments in real time.

Project overview

CourierX is a modern, responsive courier and delivery web application built to let customers book pickups, track shipments in real time, calculate rates, and manage deliveries. This repository contains the website front-end, API integration points, and deployment instructions.
